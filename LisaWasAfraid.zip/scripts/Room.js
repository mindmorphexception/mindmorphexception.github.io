RoomClass = Class.extend(
{
	backgr: null,
	x0: 0,
	x1: 0,
	y0: 0,
	y1: 0,
	entities: []
	
}
);