SpritesClass = Class.extend(
{
	drawSprite: function(sprite,x,y)
	{
		
	}
}
);