PlayerClass = Entity.extend(
{
	going: null,
}
);