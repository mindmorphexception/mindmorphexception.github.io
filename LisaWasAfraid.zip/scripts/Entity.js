EntityClass = Class.extend({
  size:  { x: 0, y: 0 },
  pos: { x: 0, y: 0 },
  sprite: null,
  
  setPos: function (x, y) 
  {
		this.pos.x = x;
		this.pos.y = y;
  },
  
  draw: function () 
  {
    if (this.sprite) 
	{
		drawSprite(this.sprite, this.pos.x.round() - this.size.x, this.pos.y.round() - this.size.y);
    }
  },
}
);
